/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 *
 * (c) 2009-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/broken-axis.src.js';
